/*
blink.cpp - Simple example in creating your own Arduino Library
Copyright (c) op from TMM. All right reserved.
I don't think I have learned it!

*/
 
#include <Arduino.h>
#include "breath.h"

Breath::Breath(int pin){
 pinMode(pin, OUTPUT);
 pinNumber = pin; 
}
 
void Breath::breath(bool value){
 if(value == true){
 digitalWrite(pinNumber,HIGH);
 delay(1000);
 digitalWrite(pinNumber,LOW);
 delay(1000);
 }else{
 digitalWrite(pinNumber,LOW);
 }
}

void Breath::breath(bool value, int breathLength ){
 if(value == true){
 digitalWrite(pinNumber,HIGH);
 delay(breathLength);
 digitalWrite(pinNumber,LOW);
 delay(breathLength);
 }else{
 digitalWrite(pinNumber,LOW);
 }
}
 
void Breath::breath(bool value, int breathLength, int breathLoops){
 if(value == true){
 for(int i=0;i<breathLoops;i++){
 digitalWrite(pinNumber,HIGH);
 delay(breathLength);
 digitalWrite(pinNumber,LOW);
 delay(breathLength);
 }
 }else{
 digitalWrite(pinNumber,LOW);
 }
}
