/*
 this is a homework for the breath led to show.
*/

#ifndef breath_h
#define breath_h

#include <Arduino.h>

#define ON true
#define OFF false

class Breath
{
public:
	Breath(int pin);  //Constructor. attach pin to blink
	void breath(bool value);  //enable blinking with 1s duration
	void breath(bool value, int breathLength);   //enable blinking with blink duration
	void breath(bool value, int breathLength, int breathLoops);  //enable blinking with blink duration and number of loops
private:
	uint8_t pinNumber;
};

#endif
